#include "stdafx.h"
#include "WalkieGC.h"
#include "WalkieC.h"
#include <iostream>

WalkieGC::WalkieGC(const std::string & filePath, int width, int height, int columns, int frameDelay_, int currentFrame, std::unordered_map<std::string, std::pair<int, int>> animations_) : frameW{ width }, frameH{ height }, frameDelay{ frameDelay_ }, currentFrame{ currentFrame }, animations{ animations_ }, columns{ columns }, state{Stop} {
	texture.loadFromFile(filePath);
	sprite.setTexture(texture);
	sprite.setTextureRect({frameW * (currentFrame % columns), (frameH * (currentFrame/columns)), frameW, frameH });
}

WalkieGC::WalkieGC(const WalkieGC & other) : frameW{ other.frameW }, frameH{ other.frameH }, frameDelay{ other.frameDelay }, currentFrame{ other.currentFrame }, animations{ other.animations }, texture{ other.texture }, currentAnimation{ other.currentAnimation }, columns{ other.columns }, state{Stop} {
	sprite.setTexture(texture);
	sprite.setTextureRect({ frameW * (currentFrame % columns), (frameH * (currentFrame / columns)), frameW, frameH });
}

WalkieGC::~WalkieGC() {}

void WalkieGC::setAnimation(const std::string & id, bool pause) {
	currentAnimation = animations[id];
	currentAnimationId = id;
	currentFrame = currentAnimation.first;
	paused = pause;
	wait = frameDelay;
}

void WalkieGC::addAnimation(const std::string & id, int start, int end) {
	animations[id] = { start, end };
}

void WalkieGC::setFrame(int frame, bool pause) {
	currentAnimation = { 0,0 };
	currentAnimationId = "";
	currentFrame = frame;
	sprite.setTextureRect({ (frameW * (currentFrame % columns)), frameH * (currentFrame / columns), frameW, frameH });
	paused = pause;
	wait = frameDelay;
}

void WalkieGC::progress() {
	if (!paused) {
		if (wait != frameDelay) {
			wait++;
		}
		else {
			sprite.setTextureRect({ (frameW * (currentFrame % columns)), frameH * (currentFrame / columns), frameW, frameH });
			wait = 0;
			if (currentAnimation.first <= currentFrame && currentFrame < currentAnimation.second) {
				currentFrame++;
			}
			else {
				currentFrame = currentAnimation.first;
			}
		}
	}
	else {
		wait = 0;
	}
}


void WalkieGC::update(std::vector<msf::Action *>& acts, sf::RenderWindow & window) {
	sprite.setPosition(owner->getPos());
	AnimationState prevState = state;
	for (auto& act : acts) {
		switch (act->id) {
		case 20:
			state = Stop;
			break;
		case 21:
			state = Right;
			break;
		case 22:
			state = Left;
			break;
		case 23:
			state = Midair;
			break;
		}
	}
	if (prevState != state) {
		switch (state)
		{
		case WalkieGC::Left:
			setAnimation("left", false);
			break;
		case WalkieGC::Right:
			setAnimation("right", false);
			break;
		case WalkieGC::Stop:
			setAnimation("stop", false);
			break;
		case WalkieGC::Midair:
			setAnimation("midair", false);
			break;
		default:
			break;
		}
	}
	progress();
	window.draw(sprite);
}

std::unique_ptr < msf::GraphicsComponent > WalkieGC::clone() {
	return std::make_unique<WalkieGC>(*this);
}
