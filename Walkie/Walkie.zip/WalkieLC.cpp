#include "stdafx.h"
#include "WalkieLC.h"
#include "WalkieC.h"


WalkieLC::WalkieLC() : collisionBox{0, 0, 7, 14}
{
}


WalkieLC::~WalkieLC()
{
}

void WalkieLC::update() {
	collisionBox.top = owner->y();
	collisionBox.left = owner->x();

	float previousX = velocity.xComp();
	bool midair{false};

	controller.readInputs();

	for (auto& act : controller.getBuffer()){
		if (act.id == WalkieC::leftd) {
			velocity += {180, .5};
		}
		if (act.id == WalkieC::rightd) {
			velocity += {0, .5};
		}
		if (act.id == WalkieC::leftu) {
			velocity += {0, .5};
		}
		if (act.id == WalkieC::rightu) {
			velocity += {180, .5};
		}
		if (act.id == WalkieC::upd) {
			velocity.yComp(-2);
		}
	}
	controller.clearBuffer();
	if (collisionBox.top + collisionBox.height > 270) {
		owner->setPos(owner->x(), 270 - collisionBox.height);
		velocity.yComp(0);
		midair = false;
	}
	else {
		if (collisionBox.top + collisionBox.height != 270) {
			velocity += {90, .05};
			midair = true;
		}

		owner->move(velocity.xComp(), velocity.yComp());
	}



	if (!midair) {
			float val = velocity.xComp();
			if (val == 0) {
				buffer.push_back(new msf::Action(20, false));
			}
			if (val > 0) {
				buffer.push_back(new msf::Action(21, false));
			}
			if (val < 0) {
				buffer.push_back(new msf::Action(22, false));
		}
	}
	else {
		buffer.push_back(new msf::Action(23, false));
	}
}

std::unique_ptr<msf::LogicComponent> WalkieLC::clone() {
	return std::make_unique<WalkieLC>(*this);
}
