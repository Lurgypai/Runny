#pragma once
#include "MSF.h"
#include "WalkieC.h"
class WalkieLC : public msf::LogicComponent {
public:
	WalkieLC();
	~WalkieLC();

	void update() override;
	std::unique_ptr<msf::LogicComponent> clone() override;
private:
	msf::MVector velocity;
	sf::FloatRect collisionBox;
	WalkieC controller;
};

